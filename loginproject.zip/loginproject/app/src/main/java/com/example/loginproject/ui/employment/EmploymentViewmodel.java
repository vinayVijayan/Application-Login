package com.example.loginproject.ui.employment;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class EmploymentViewmodel extends ViewModel {

    private MutableLiveData<String> mText;

    public EmploymentViewmodel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is gallery fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}